---
name: 9router-image
description: Generate images via 9Router /v1/images/generations.
---

# 9Router — Image Generation

Source: https://raw.githubusercontent.com/decolua/9router/refs/heads/master/skills/9router-image/SKILL.md

Use when generating a picture, illustration, or text-to-image asset on this host.

Gateway on this host: `http://127.0.0.1:20128` (the value of `NINEROUTER_URL` for this install).
Key lives in `~/.9router/db/data.sqlite` table `apiKeys` (read it in a script; never echo it
into chat or logs). Hermes' own key is `$HERMES_CUSTOM_LOCALHOST_20128_API_KEY`.

## Prerequisite — a provider must have credentials

The endpoint exists even when it cannot work. **Check before claiming anything is possible:**

```bash
curl -s "$NINEROUTER_URL/v1/models/image" -H "Authorization: Bearer $KEY"
# {"object":"list","data":[]}  <- empty means NO image provider is configured
```

An empty list (or `{"error":{"message":"No credentials for provider: <name>"}}` on POST)
means a key must be added first in the 9Router dashboard -> Media Providers. Do not report
success off an empty catalog; do not substitute a different generator silently.

## Discover

```bash
curl $NINEROUTER_URL/v1/models/image | jq '.data[].id'
curl "$NINEROUTER_URL/v1/models/info?id=openai/dall-e-3"   # per-model params
```

## Endpoint

`POST $NINEROUTER_URL/v1/images/generations`

| Field | Required | Notes |
|---|---|---|
| `model` | yes | from `/v1/models/image` |
| `prompt` | yes | image description |
| `n` | no | provider-dependent |
| `size` | no | `1024x1024`, `1792x1024`, ... |
| `quality` | no | `standard` / `hd` (OpenAI) |
| `response_format` | no | `url` (default) or `b64_json` |

Add query `?response_format=binary` to get raw bytes — easiest way to save a file:

```bash
curl -X POST "$NINEROUTER_URL/v1/images/generations?response_format=binary" \
  -H "Authorization: Bearer $KEY" -H "Content-Type: application/json" \
  -d '{"model":"gemini/gemini-3-pro-image-preview","prompt":"watercolor mountains","size":"1024x1024"}' \
  --output out.png
```

## Response shape

`{"created":..., "data":[{"url":"https://..."}]}` or `{"data":[{"b64_json":"iVBORw0..."}]}`.
With `?response_format=binary`, raw bytes with `Content-Type: image/png`.

## Provider quirks

| Provider | Extra/changed fields | Notes |
|---|---|---|
| `openai`, `minimax`, `openrouter`, `recraft` | `quality`, `style`, `response_format` | Standard OpenAI shape |
| `gemini` (nano-banana) | — | Only `prompt`; ignores `size`/`n` |
| `codex` (gpt-5.4-image) | `image`, `images[]`, `image_detail`, `output_format`, `background` | SSE stream; ChatGPT Plus/Pro required |
| `huggingface` | — | Only `prompt`; single image |
| `nanobanana` | `image`, `images[]` (edit mode) | `size` -> aspect ratio; async polling |
| `fal-ai` | `image` (img2img) | `n` -> `num_images`; `size` -> ratio; async |
| `stability-ai` | `style` (preset), `output_format` | `size` -> `aspect_ratio` |
| `black-forest-labs` (FLUX) | `image` (ref) | `size` -> exact `width`/`height`; async |
| `runwayml` | `image` (ref) | `size` -> ratio; async; video models exist |
| `sdwebui`, `comfyui` | — | Localhost noAuth (`:7860` / `:8188`) |

## Model names seen in this install's catalog

`gemini-2.5-flash-image`, `gemini-3.1-flash-image`, `gemini-3.1-flash-image-preview`,
`grok-imagine-image`, `grok-imagine-image-2`, `grok-imagine-image-quality`, `flux`.
Present in the catalog is NOT the same as usable — the catalog is metadata; credentials
decide what the gateway will actually call.

## Pitfalls

- **Read the provider table, not the catalog.** A model listed in `model-catalog.json` means
  nothing about whether a key exists. `providerConnections` is the source of truth.
- **A 400 naming the provider is the useful error.** `No credentials for provider: X` tells you
  exactly which dashboard entry is missing.
- **Text models cannot cover.** `imageOutput: false` on every `/v1/models` entry means no image
  path exists yet; fall back to a local renderer and say so rather than passing text off as an image.
