# 9router Image Generation Troubleshooting

## Empty Catalog Diagnosis (Session Log)

**Issue:** Image catalog returned empty even when endpoint is reachable.

```json
{"object":"list","data":[]}
```

**Root Cause:** No providers configured in 9Router dashboard.

**Diagnostic Command:**
```bash
curl -s "http://127.0.0.1:20128/v1/models/image" \
  -H "Authorization: Bearer $HERMES_CUSTOM_LOCALHOST_20128_API_KEY"
```

**Key Finding:** `data: []` != broken endpoint. Endpoint exists; credentials missing.

## Fallback Pattern When No Providers

Per skill guidance: "fall back to a local renderer and say so rather than passing text off as an image."

**Alternatives:**
1. **html-to-carousel** (Playwright based) - for technical carousels
2. **Local Stable Diffusion** via sd-webui/comfyui
3. **Text-based visualization** via matplotlib/seaborn for data

## Dashboard Access Required

To enable 9router:
1. Navigate to 9Router dashboard -> Media Providers
2. Add credentials for: OpenAI, Gemini, Flux, etc.
3. Verify with catalog check before use

## Critical: Provider vs Catalog

A model appears in `model-catalog.json` DOES NOT mean it's usable. Only `providerConnections` in the dashboard determines actual availability.