---
name: linkedin-outreach
description: LinkedIn outreach automation via browser automation.
version: 1.0.0
tags: [linkedin, outreach, automation, camofox, chrome-cdp, connection-requests, messaging, posts]
---

# LinkedIn Outreach Automation

Use this skill when the user asks to:
- Send LinkedIn connection requests programmatically
- Send InMail or messages to LinkedIn profiles
- Post to LinkedIn feed via automation
- Run LinkedIn outreach campaigns (sequences, templates, scheduling)
- Debug LinkedIn automation failures

## Platform realities

### Anti-bot escalation — full-domain blocking (2026-08-21)

LinkedIn's anti-bot detection now blocks automated browser fingerprints at multiple levels simultaneously, regardless of cookie state. Three distinct symptoms were observed in a single session, all server-side blocks:

**Symptom 1: `NS_ERROR_NET_EMPTY_RESPONSE`** — network-level connection drop on `/feed/` and `/in/<profile>/`. LinkedIn drops the connection entirely rather than returning a page.

**Symptom 2: `NS_ERROR_REDIRECT_LOOP`** — Firefox redirect loop detection on homepage (`/`). Firefox error page: "The page isn't redirecting properly", "Camoufox can't connect to the server at www.linkedin.com". Earlier in the session the homepage loaded (redirecting to `hp`), but escalated to full redirect loop.

**Symptom 3: "Problem loading page" with empty DOM** — profile pages (`/in/<profile>/`) render a Firefox error page. `document.title` = "Problem loading page", `document.body.innerText` = `""`, `document.querySelectorAll("button")` = `[]`. URL still shows the profile URL. Clicking "Try Again" does not break the loop.

**What does NOT work:**
- Cookie import alone (any browser backend, any cookie set) — produces blocked/empty pages, NOT working sessions
- Clicking "Try Again" on "Problem loading page" — re-blocks immediately
- Multiple retries of the same blocked approach
- Different `userId` / `sessionKey` — same behavior
- Waiting and retrying

**Verification method (page-state evidence, NOT HTTP status):**
- `document.title` — if "Problem loading page", blocked
- `document.body.innerText` — if empty, blocked
- `document.querySelectorAll("button")` — if `[]`, no interactive elements
- URL — if `/login` or `/signin`, not authenticated
- HTTP 200 alone does NOT confirm a working session

**What works:**
- **Option A**: Manual login in Camofox (visible browser, not headless), then reuse the `userId`/`sessionKey` profile. Only verified working approach.
- **Option B**: LinkedIn Official API (requires Developer account, OAuth, approval)
- **Option C**: Wait and retry (no guarantee)

**Decision tree:**
```
Need LinkedIn automation?
├── Can user manually log in to Camofox once?
│   └── YES → Manual login, reuse profile, then run scripts
├── Is LinkedIn API access available?
│   └── YES → Use official API
└── NO to both
    └── LinkedIn automation is NOT currently possible
        → Focus on working channels (WhatsApp, X, etc.)
```

### Verified failure mode

```
Navigating to https://www.linkedin.com/feed/:
  NS_ERROR_NET_EMPTY_RESPONSE
  Call log: navigating to "https://www.linkedin.com/feed/", waiting until "domcontentloaded"

On homepage (https://www.linkedin.com/):
  Redirects to https://www.linkedin.com/hp (logged out)
  Snapshot shows "Sign in" / "Agree & Join LinkedIn"
```

Cookie import response:
```
POST /sessions/linkedin_main/cookies  →  {"ok":true,"userId":"linkedin_main","count":24}
```
But subsequent tab creation shows login page — cookies not applied to browser context.

## Working alternatives

### Option A: Chrome CDP with existing LinkedIn session

If a Chrome/Chromium profile has an active LinkedIn session (cookies in `Default/Cookies` SQLite database), use Chrome CDP directly. LinkedIn treats Chrome as a normal browser and won't block it.

**Preconditions:**
- Chrome/Chromium installed (`which google-chrome` → `/usr/bin/google-chrome` in this env)
- Chrome profile with LinkedIn cookies exists
- CDP port reachable (launch Chrome with `--remote-debugging-port=9222`)

**Launch:**
```bash
google-chrome --remote-debugging-port=9222 \
  --no-first-run --no-default-browser-check \
  --user-data-dir=/path/to/chrome-profile \
  --headless=new --disable-gpu --disable-dev-shm-usage \
  --disable-background-networking --disable-sync
```

**Verify CDP:**
```bash
curl http://localhost:9222/json/list  # should return tabs
```

**Navigate to LinkedIn:**
Use CDP commands or Playwright with the Chrome profile.

### Option B: Playwright Chromium + cookie import

Import LinkedIn cookies into a Playwright Chromium context. This is the verified path from `browser-social-composer` for X — same pattern works for LinkedIn.

```javascript
const browser = await chromium.launch({ headless: true });
const context = await browser.newContext();
const cookies = JSON.parse(fs.readFileSync('linkedin-cookies.json', 'utf8'));
await context.addCookies(cookies);
const page = await context.newPage();
await page.goto('https://www.linkedin.com/feed/');
// Verify not on login page
```

**Caveat:** LinkedIn may still detect headless Chromium. Use a real Chrome user agent and non-headless if possible.

## What doesn't work

| Approach | Result |
|---|---|
| Camofox Firefox + cookie import (REST API) | Login page, NS_ERROR_NET_EMPTY_RESPONSE on feed |
| Camofox Firefox + cookie import (via newContext.addCookies) | Same — cookies accepted but session invalid |
| Camofox Firefox direct navigation to `/feed/` | NS_ERROR_NET_EMPTY_RESPONSE |
| Camofox Firefox direct navigation to `/in/<profile>/` | NS_ERROR_NET_EMPTY_RESPONSE |

## Template system

Templates for LinkedIn outreach messages and posts. Supports variable substitution with `{{variable}}` syntax.

**Template types:**
- `connection` — connection request notes (limit: 300 chars)
- `message` — InMail / direct messages (post-connection)
- `post` — feed posts (limit: 3000 chars)

**Available templates:**
- `connection-cold` — first connection request (variants: default, short, professional)
- `connection-warm` — after engaging with content (variants: default, event)
- `followup-after-connect` — post-connection follow-up (variants: default, brief, soft)
- `cold-outreach` — direct value proposition (variants: value_first, question_based, short_pitch)
- `event-followup` — after meeting at conference (variants: default, no_resource)
- `engagement-to-dm` — after engaging with post (variants: default, short)
- `referral-request` — ask for referral/intro (variants: direct, soft)
- `reengagement` — re-contact dormant lead (variants: default, update_only)
- `thank-you` — appreciation (variants: default, brief)
- `post-thought-leadership` — insight post (variants: story, contrarian, how_to, lesson_learned)
- `post-announcement` — company/product news (variants: launch, milestone)
- `post-engagement` — conversation starter (variants: poll_style, debate, ask_experts)

**Render a template:**
```bash
node linkedin_templates.js render connection-cold --variant short --firstName "Sarah" --company "Acme" --role "CTO"
```

## Campaign engine structure

The campaign engine orchestrates LinkedIn actions with templates, targets, rate limiting, and state tracking.

**Actions supported:**
- `post` — post to LinkedIn feed
- `connect` — send connection request (with optional note)
- `message` — send InMail/message (requires existing connection)

**Campaign config:**
```json
{
  "name": "Outreach to CTOs",
  "actions": [
    {"type": "connect", "note": "Hi {{firstName}}..."},
    {"type": "message", "message": "Thanks for connecting..."}
  ],
  "targets": [
    {"profileUrl": "https://linkedin.com/in/person1", "firstName": "John"}
  ],
  "rateLimitMs": 30000,
  "dryRun": false
}
```

**Run:**
```bash
node linkedin_campaign.js campaign --config campaign.json
```

**State tracking:** Actions are logged to `linkedin-campaign-state.json` with timestamps, success/failure, and targets. History is queryable via `node linkedin_campaign.js status`.

## Rate limiting

LinkedIn enforces strict rate limits on connection requests and messages. Default campaign rate limit is 30s between actions. Do not reduce this without testing. Connection request limits are particularly tight — exceeding them risks account restriction.

## Verification

After any LinkedIn action, verify with:
1. **URL check** — not on `/login` or `/signin`
2. **Snapshot** — page content confirms expected state
3. **Screenshot** — visual proof saved to `/tmp/linkedin-<action>-<timestamp>.png`

Do not declare success from HTTP status alone. LinkedIn can return 200 on login page.

## Script debugging guide

See `references/linkedin-script-debugging.md` for:
- Diagnostic probe script template (standalone tab + navigate + snapshot + button find)
- Missing `log()` function fix
- Embedded null bytes in script files — diagnosis and cleaning
- Playwright pseudo-selectors (`:has-text()`, `:contains()`) do NOT work in Camofox Firefox — replace with `querySelectorAll` + text content matching
- Snapshot return value: return `res` not `res.snapshot`
- Cookie import must be called in the main flow before `createTab()`, not just defined
- Default tab URL must be `https://www.linkedin.com/`, not `about:blank`

## Anti-bot failure modes

LinkedIn blocks automated browser profiles at the network/server level. Two manifestations observed:

1. **`NS_ERROR_NET_EMPTY_RESPONSE`** on `/feed/` and `/in/<profile>/` — network-level connection drop. See `references/linkedin-anti-bot-redirect-loop.md` for full analysis.
2. **"The page isn't redirecting properly"** on profile URLs — Firefox redirect loop detection. Same root cause (browser fingerprint blocked), different symptom. Clicking "Try Again" does not break the loop.

Cookie import via REST API accepts cookies but does not produce an authenticated session. The only verified working approach is manual login in a visible Camofox browser.

## Related skills

- `camofox-social-automation` — Camofox patterns, composer behavior, fallback rules
- `browser-social-composer` — Playwright cookie-backed posting fallback
- `outreach-automation` — campaign engine structure (WhatsApp + X focused)
- `x-social-poster` — X/Twitter posting via Camofox (pattern transfers to LinkedIn)
