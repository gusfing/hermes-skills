---
name: multi-agent-orchestration
description: >
  Use multiple parallel agents for complex tasks. Delegate independent
  subtasks to concurrent subagents instead of serializing them. Each
  subagent gets isolated context and returns only a final summary.
  Use when a task has 2+ independent workstreams that don’t depend on
  each other’s output.
---

# Multi-Agent Orchestration

## When to use

- Research + implementation + review can happen in parallel
- Multiple platforms/tools need independent setup (X, WhatsApp, dashboard)
- Audit + build + research are separable

## Pattern

1. Split the task into 2–3 independent subtasks
2. Dispatch via `delegate_task(tasks=[...])`
3. Do NOT wait/poll — continue working in the foreground
4. Consolidated results arrive as a single async message

## Subagent contract

- Each subagent gets its own isolated context
- No shared state between subagents
- Final summary only — no intermediate tool results leak to parent
- Maximum concurrency: 3 tasks per batch for this user

## Pitfalls

- Do NOT serialize subagents that are truly independent
- Do NOT pass sensitive credentials in subagent context
- Do NOT expect subagents to have memory of the parent conversation
- Do NOT nest delegation deeper than 1 level

## Example split

For "build outreach system":
- Agent 1: Research WhatsApp libs + install steps
- Agent 2: Audit existing dashboard/engine bugs
- Agent 3: Build reusable X poster CLI

All three run in parallel, return summaries, parent synthesizes.
