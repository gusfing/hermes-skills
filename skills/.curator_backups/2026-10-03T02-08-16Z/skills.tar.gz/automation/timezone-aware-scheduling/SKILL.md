---
name: timezone-aware-scheduling
description: Use when recurring jobs must land in a user's local hours.
---

# Scheduling in the audience's timezone

Class of task: "post 8x/day", "engage every 30 min", "run this between 9 and 5".
The host clock is almost never the audience clock. If the schedule is computed
in server time and only *displayed* differently, the bug is invisible until the
user reads it back at 23:00 local and says "it's 10:55 in Delhi".

## The rule

**Convert at the source.** The generator, not the display layer, must produce
times in the audience's zone. Fixing the output formatting while leaving UTC
slots underneath is a cosmetic patch on a real bug.

```python
from datetime import datetime, timedelta, timezone
IST = timezone(timedelta(hours=5, minutes=30))   # named for the audience, not the host

def now():
    return datetime.now(IST)

def ist_day():
    """Today for the audience. Near midnight UTC it is already tomorrow in
    Delhi, so generating slots from the UTC date builds the wrong day's plan."""
    return datetime.now(IST).date()
```

Print **both** zones afterwards. A plan that only shows IST stops the next
reader from noticing a regression; a plan that only shows UTC is how the bug
ships.

## Do not set TZ for the process

```bash
TZ=Asia/Kolkata python x_schedule.py --plan   # WRONG if the script also prints a UTC column
```

With `TZ` exported, every naive `datetime` renders in that zone, so a script
designed to print "IST | UTC" prints the **same value twice** and the UTC
column silently becomes a lie. Convert explicitly in Python with a real
`tzinfo` instead, and leave the host timezone alone.

## Verify the schedule in the target zone, then stop

The verification that actually catches this is: list the next N fires, convert
them, and check the window. Do this before declaring the schedule fixed.

```python
IST = timezone(timedelta(hours=5, minutes=30))
# parse the timer's NextElapseUSecRealtime, then:
print(dt.astimezone(IST).strftime('%H:%M IST (%a)'))
```

Do **not** do the conversion in shell with `date -u -d '+5:30'` and string
surgery — that was tried and produced an unchanged timestamp with no error.
`strptime` + `.replace(tzinfo=utc)` + `.astimezone(IST)` in Python is the
shortest correct path.

Sanity-check the offset direction once, out loud, in the output: server
`17:25 UTC` must read `22:55 IST`. If it does not, the sign is wrong.

## systemd timers: see `references/systemd-oncalendar-traps.md`

`OnCalendar` is the usual mechanism and it has several silent-failure modes: a
comma hour list fires **once a day** at the last hour, and a `:MM/repeat` spec
parses but yields `Trigger: n/a` and never fires. Both pass
`systemd-analyze --user verify`. Read the reference before writing a timer.

**Ranges are hour ranges.** `03:30..21:30` is invalid syntax, so an audience
window that does not land on the hour cannot be written as a range. Use one
`OnCalendar=` line per time-of-day with a bare reset line first — that is the
documented list idiom, not a mistake.

**Prove the window, do not infer it.** `systemd-analyze calendar` prints only
the *next* elapse, so counting its output reports 1 fire even for a correct
every-30-min spec — that mistake produced a confident, wrong "fires once a
day" call. Read `Normalized form` for every line, and run
`scripts/check_timer_window.py <unit>…` which does it live, also flagging an
empty list and an unarmed `Trigger: n/a`.

## A window that is correct in UTC can still be wrong locally

A range crossing local midnight is contiguous in UTC and looks fine in
`list-timers` output while the audience sees a different day. When the user
names a local window, convert **both edges** and state them in local time in
your reply — the UTC table is for you, the local table is the one that gets
read.

## Applies to

Posting schedules, engagement ticks, cron entries, drip campaigns, any
recurring job whose *audience* is a human in a specific timezone. Same bug
shape as "email the digest at 8am" where the host is UTC — it is a 1:30am
delivery, and nothing anywhere reports an error.
