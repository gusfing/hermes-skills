# Automated posting: cadence, media, and "it looks the same" reports

Class of task: a scheduler posts from a fixed content pool on a timer, and the
user reports *"you are posting the same post"* or *"no image"*. Both reports are
checkable, and answering them requires care — one was half right, and the real
defect sat next to it.

## Check the claim before agreeing or disputing it

The instinct is to defend. Measure first — the claim is either right, wrong,
or (as here) right about one thing and pointing at the wrong one.

```python
# 1. distinct content actually posted today, from the state file
st = json.loads(Path("x_state.json").read_text())
for p in st["posted"]:
    print(p["t"], p["kind"], p.get("file"))

# 2. how many distinct files, and how much of the pool is left
pool = [p.name for p in Path("x_pool").glob("*.txt")]
used = set(json.loads(Path("x_used.json").read_text()))
print("pool", len(pool), "used", len(used), "unused",
      [n for n in pool if n not in used])
```

Here it showed 7 genuinely distinct posts — so "same post" was wrong — but the
same read surfaced the actual bug: three feed posts inside 22 minutes while the
timeline reported those slots as `skipped`. **Report the measurement, not the
defence, and let the correction point at the real defect.**

## Read state timestamps as UTC unless proven otherwise

State files often store `"2026-10-01T03:46:00"` with no zone, produced by a
script running on a UTC host. Sorting them against `datetime.now()` on a local
box silently reorders the day and makes a clean schedule look bursty. Convert
explicitly before drawing any conclusion about spacing:

```python
IST = timezone(timedelta(hours=5, minutes=30))
ts = datetime.fromisoformat(rec["t"]).replace(tzinfo=IST).timestamp()
```

## The reuse fallbacks are the real cadence bug

Two functions decide *what* to post when the pool is thin, and both make reuse
the graceful-degradation path:

```python
def pick(pool, used, exclude=()):
    fresh = [p for p in pool if p.name not in used and p.stem not in exclude]
    return random.choice(fresh or [p for p in pool if p.name not in used] or pool)
    #                                        ^^^^ reuse       ^^^^^^^^^^ any post

def assign_posts(slots, pool, used):
    avail = [p for p in pool if p.name not in used]
    if len(avail) < len(slots):
        avail = pool     # exhausted -> reuse rather than skip a slot
```

The final `or pool` means exhausting the pool produces **repeats instead of
pausing**, and `assign_posts` pads short picks by re-drawing from the whole
pool. A user watching the timeline will absolutely call this "posting the same
post" — and they are right about the behaviour even when the specific post
differs.

The floor is therefore not enforced by the picker but only by a separate
min-gap check in the caller. When the picker can draw anything and the floor
lives elsewhere, any caller that forgets the floor bursts. Prefer a pool-size
check that **refuses to post** over one that silently reuses:

```python
avail = [p for p in pool if p.name not in used]
if len(avail) < len(slots):
    print(f"[plan] only {len(avail)} unused of {len(slots)} slots -> post fewer")
    slots = slots[:len(avail)]      # drop slots, never widen the pool
```

## Attach media to every post, and prove it

Text-only posts read as low-effort. Resolve art **by stem beside the content**
(`x_media/<pool-name>.png`) so adding art is dropping in one file with no code
change:

```python
media = HERE / "x_media" / (Path(slot["file"]).stem + ".png")
r = x_post.post(pg, text, slot.get("community"), media if media.exists() else None)
```

The platform's own file input is the only reliable attach mechanism, and the
preview node is the only proof — see the Media upload section of `x-automation`.

**Verify coverage for every content item, not a sample.** A partial mapping
posts text-only for the rest and looks like the feature is intermittently
broken:

```bash
for f in x_pool/*.txt; do n=$(basename "$f" .txt)
  [ -f "x_media/$n.png" ] || echo "MISS $n"; done
# must print nothing
```

Note when grepping the result: `ls | grep -v _` silently filters every file if
the naming convention contains underscores. Count with a pattern that matches
the extension instead.

## Do not force a post to prove a feature works

Asked to demonstrate the media path, the last post was 20 minutes old against a
90-minute floor. The correct move is to **say so and let the scheduler do it** —
verify the wiring by resolving the mapping for upcoming slots instead:

```python
for s in slots[:6]:
    m = Path("x_media") / (Path(s["file"]).stem + ".png")
    print(s["at"], Path(s["file"]).name, "->", m.name, m.exists())
```

Overriding the pacing rule to showcase a capability reintroduces exactly the
burst the floor exists to prevent, and the demonstration is not evidence the
scheduler works anyway.

## Generated media needs a visual check before it ships

See `x-automation` for the full workflow. The one-line version: **models invent
text even when told not to**, so `vision_analyze` every image ("any readable
words? yes/no first") and regenerate failures before anything reaches a public
post. A fabricated brand name in an attached image is a published mistake.