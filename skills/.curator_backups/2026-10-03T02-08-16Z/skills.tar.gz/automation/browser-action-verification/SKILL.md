---
name: browser-action-verification
description: Use when confirming a browser write actually landed.
---

# Verifying an automated browser action landed

Class of task: a script posts, comments, likes, DMs, or deletes through a
browser driver, and you must report success or failure. The click is not
evidence. **The check afterwards decides the answer, and a check that reads the
wrong thing produces confident false negatives that are worse than no check.**

## The rule

**Verify on the transport, not the rendered view.** A control counts only if it
reads state the platform itself changed.

| action | control that works | control that lies |
|---|---|---|
| like / react | aria-label flips `"no reaction"` → `"reaction"` | counting visible buttons |
| comment | the create POST → **HTTP 200** | editor cleared; page text; absence from a tab |
| form submit | HTTP 2xx on the POST | click returned, spinner stopped |
| deletion | the **gone-marker** in the permalink | "no article rendered" |

Implementation, and the full incident behind this table:
`references/verifying-a-write-landed.md`.

## Negative results

`absent is not proof of absence`. When a check says "not found" and that
contradicts expectation, find the **positive marker** the platform emits for the
thing being gone and require that instead.

Sharpest instance: after deleting a post, the permalink still renders a page —
it renders a *tombstone*. "No article found" and "post deleted" are
indistinguishable by article presence alone. Only an explicit gone-marker
(`page doesn't exist`) settles it.

Corollary: **a view that is supposed to refresh after a write is the least
reliable control available.** It lags, it paginates, it may not be rendered at
all. Never gate a write report on it.

## Capture the permalink while the card is in hand

Asked to show *what* you liked or commented on, the instinct is to go back later
and look each post up. Do not — act on the card that is already open, and read
the link out of it. The two platforms differ on whether that is even possible.

| platform | link available from the card? | how |
|---|---|---|
| X | **Yes, always** | `/i/status/<id>` resolves without auth |
| LinkedIn | **No** | no permalink, no `urn:li:activity`, no `<time>` |

Measured LinkedIn feed card, every anchor present: `/in/<author>/`,
`/company/<co>/`, `/search/results/all/?keywords=…`, `/`, `"300 reactions"`,
`"Send"`. The timestamp anchor is **`href="/"`**. There is no `data-id` and no
`<time>` element anywhere in the card.

**The activity id is only materialised when a post is expanded or opened.** So
there is no extraction to retry — the attribute is not in the DOM yet. If you
find yourself hunting harder selectors, you are chasing a field that does not
exist; stop and report the limit instead of shipping an extractor that returns
an empty or fabricated URL.

Getting LinkedIn URLs is therefore a **separate, slow pass** that opens each
acted-on post and records the resulting address (~5–10s per post), not a change
to the engagement script. It slows and makes the automation more detectable, so
it is a decision to put to the user, not a silent optimisation.

When a link is genuinely unavailable, show the post text and **say why in the
surface itself**. A blank cell reads as a bug; a stated reason reads as a
design. Revert a working-looking-but-unverified extractor rather than shipping
it — this one produced plausible URLs that could not be followed.

Older rows cannot be backfilled: start recording at the code change. Say the
cutoff date when you hand the surface over.

## Response bodies are not the status

For action POSTs the **status code** is reliable and the **body often is not** —
`Network.getResponseBody` can return `-32000 No data found for resource` on a
request that succeeded. Require the status; ignore the body.

Drain buffered `Network` events *before* acting, or a leftover response from a
previous tick is attributed to this one.

## "It works" needs a source you did not write

A response can look correct and still be served by the wrong process. Before
reporting a deploy as live, confirm the responder is the unit you just started —
a **404 on a route you just added** is the tell, because the process answering
predates the code.

```bash
systemctl --user is-active <unit>.service
systemctl --user show <unit>.service -p NRestarts -p ActiveEnterTimestamp
pgrep -af "[s]erver_name\.py"        # brackets: never match own cmdline
sudo -n ss -ltnp | grep :8791        # who actually owns the socket
```

`NRestarts: 0` plus a fresh `ActiveEnterTimestamp` is the proof. A port that
answers is not evidence — a stale hand-launched copy of the same process will
answer happily with pre-deploy code. A feature route 404ing while the port is
"up" is exactly this, and it invalidates any earlier claim that the feature
shipped.

## A verifier that fails on everything is the suspect

The rule above is about the *check* being wrong. The sharpest form of it: when a
verification pass rejects **every single row**, that is the signature of a check
that inspected nothing, not of uniformly bad data. An empty result set fed into
`any(...)` reports "no match" forever.

An 8s settle after `goto` returned an empty article list; the comparator printed
`MISMATCH` for two URLs that were correct. I was one step from reverting good
data on the authority of a check that had never looked at anything.

**Make every negative check report what it saw** — count of elements inspected,
first element's text — so "found nothing" is distinguishable from "found the
wrong thing". Re-run with a longer settle and a second independent signal before
you destroy anything on the strength of one failure. Details in
`references/hosting-an-internal-dashboard.md`.

## Backfilling a field the writer never captured

A missing permalink is often a **capture** bug, not a display bug: the confirm
step searched page *text* for `/handle/status/<id>` when the id exists only in
the `href` attribute, so every post was stored with `null` forever. Symptom
shape: the surface shows "no link stored" for rows that certainly have posts.

Two traps on the repair path, both hit here: matching on a **30-char prefix**
attaches the *wrong* (but real, plausible-looking) permalink because posts share
openings — use a 70-char slice; and take the article's **first** `/status/` href,
since later ones are `/analytics` and quoted posts. Reuse the
capture-while-in-hand table above, then re-verify on the network.

## Report the shape of the uncertainty

An action log that counts *my* actions ("23 likes, 16 replies") is not a
result. Say which — engagement received, impressions, signups. If the platform
gates the outcome metric behind a paywall, say so plainly rather than letting
the action count stand in for impact.

## When did it last run? Build a ledger, not a count

A count answers "how much", never "when". The user will ask when, and if the
answer lives only in a systemd text log the answer is "read this yourself".

A per-run ledger (JSON lines, one row per attempt, outcome vocabulary that
separates *did work* from *correctly did nothing* from *failed*) is the surface
that answers it. Critical detail: **record the runs that never acquired the
resource as well as the runs that did** — if every record call sits inside the
critical section, a run that never got in leaves no trace and is invisible.

Implementation, the outcome vocabulary, and the "it's running needs a scheduled
unit, not a working script" check: `references/scheduled-automation-observability.md`.

## "It looks like the same post" — check the pool, not the defence

When a user reports repetitive or missing-media posts, measure before agreeing
or disputing: list distinct files actually posted, and how much of the pool is
unused. A picker whose fallbacks end in `or pool` converts a thin pool into
**repeats instead of pauses**, and thin it got. See
`references/automated-post-cadence.md` for the reuse-fallback fix, the UTC
timestamp trap in state files, media-by-stem resolution, and why you must not
force a post to prove a feature works.

## A correct metric with a wrong threshold is still a false finding

The sharpest form of "check the right thing": the computation can be
statistically flawless and still not measure the property you care about.
Session 2026-10-02, 23 generated post images. I computed pairwise colour
distance across all files and reported **"58 near-identical pairs out of
253"** — two genuinely different subjects, `13_confession.png` (a paper plane)
and `16_contrarian.png` (an hourglass). What my distance was actually
measuring was **shared brand palette**, which the images are *supposed* to
share. I nearly deduplicated a healthy asset library on the strength of a
metric that was correct and misnamed.

**Ask what the metric is a proxy for, before you act on a threshold.** A
threshold you invented mid-analysis has no external validation behind it.

Corollaries:

- When a cheap numeric metric flags a batch of creative work, **confirm on two
  items by eye or by inspection before touching anything.** Two confirmations
  cost seconds; a wrong "dedupe" destroys assets and is unrecoverable.
- **Self-correction is a result, not a failure to hide.** Report it plainly and
  withdraw the finding. Silently dropping the claim leaves the user believing it.
- A uniform palette across a set is usually a **brand strength**. Treat
  consistency you deliberately built as the baseline, not as the duplication
  you are hunting.

## An account check that refuses is working, not broken

Before trusting any third-party posting driver, run its account check. A driver
that reports `"logged_in": false` and refuses to emit is **correctly refusing** —
it is the same property as a gate that can halt. Reporting that as "the tool is
not set up" invites someone to bypass the guard, which is the opposite of what
the check is for.

Distinguish three states explicitly, as they need opposite responses:

| state | meaning |
|---|---|
| not logged in | correct refusal; sign in first |
| logged in, wrong account | **worse than not logged in** — pin the expected handle |
| logged in, right account | proceed |

## Related

- `references/verifying-a-write-landed.md` — the four-false-negatives incident
  and a `Network.responseReceived` implementation
- `references/scheduled-automation-observability.md` — per-run ledgers, and
  distinguishing "ran, nothing due" from "never ran"
- `references/hosting-an-internal-dashboard.md` — serving per-action rows with
  links, X-vs-LinkedIn permalink reality, the three-case public-URL auth matrix,
  and what to state at handover
- `timezone-aware-scheduling` — audience-local windows, `OnCalendar` traps,
  and a `scripts/check_timer_window.py` probe
- `cloudflare-service-exposure` — tunnels vs A-record, and the auth-bypass trap
  when a tunnel targets the app port directly
- `linkedin-feed-engagement` — measured LinkedIn selectors; user-owned, not
  curator-editable (recommend `hermes curator adopt linkedin-feed-engagement`)
